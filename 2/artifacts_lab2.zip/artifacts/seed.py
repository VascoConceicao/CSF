#!/usr/bin/env python3
import hashlib

seed0 = "TheByteOf78"
seed76 = "6b508266ad2ab9fd7fef0ecfca4b9d874ed3e0362bbf92cf2b269b0f632f452b"
timestamp = "1758588601"
n_zip = 74
s = seed0
for i in range(1, 77):
    s = hashlib.sha256(s.encode("utf-8")).hexdigest()
    if i == n_zip:
        pw = hashlib.sha256((s + timestamp).encode("utf-8"))
        print(f"pw: {pw.hexdigest()}")

print("seed_76 matches target?", s == seed76)
