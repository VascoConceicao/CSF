pasta discoveries = artifacts :)
Não mudamos o nome porque os scrips usam essa pasta.